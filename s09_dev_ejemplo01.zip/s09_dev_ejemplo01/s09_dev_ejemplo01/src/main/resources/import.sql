INSERT INTO curso (vchCurNombre,intCurCreditos) VALUES('Programmer', 5);
INSERT INTO curso (vchCurNombre,intCurCreditos) VALUES('Developer', 5);
INSERT INTO curso (vchCurNombre,intCurCreditos) VALUES('Expert', 5);


/* Creamos algunos usuarios con sus roles */
INSERT INTO `users` (username, password, enabled) VALUES ('emaravi','$2a$10$ey0G3NiePMxk09YKeOGizO60.nVnFazuFSgeGXt53iFFPfqfipduK',1);
INSERT INTO `users` (username, password, enabled) VALUES ('admin','$2a$10$16pnLLLe4vt5PQ44OdhQWeCWv.pHQhW0Mt4CsbXh6AFdBPe3k5K.O',1);

INSERT INTO `authorities` (userId, authority) VALUES (1,'ROLE_USER');
INSERT INTO `authorities` (userId, authority) VALUES (2,'ROLE_ADMIN');
INSERT INTO `authorities` (userId, authority) VALUES (2,'ROLE_USER');
