package com.cjava.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S09DevEjemplo01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
